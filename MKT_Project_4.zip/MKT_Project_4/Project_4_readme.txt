1. MKT_Project_4.pdf: The final report;
2. Project_4_EDA_Data_Cleaning.ipynb: Python code to clean the data and do EDA analysis;
3. Project_4_final.rmd: R markdown code to build the model and calculate each component's contribution;
4. csv files:
	r_df.csv: cleaned data after the data cleaning done by Python;
	dueto1.csv: each component's DueTo for Product 1 in every week;
	dueto2.csv: each component's DueTo for Product 2 in every week;
	dueto3.csv: each component's DueTo for Product 3 in every week;